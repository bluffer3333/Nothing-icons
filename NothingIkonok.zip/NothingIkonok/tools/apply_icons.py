#!/usr/bin/env python3
"""Az Ikon Szkenner által mentett ZIP-et beilleszti az ikoncsomag modulba.

Keresi: iconpack-input/*.zip  (ha több van, a legutóbb feltöltöttet használja)
Ír:     iconpack/src/main/res/drawable-nodpi/*.png
        iconpack/src/main/res/xml/appfilter.xml (+ assets/appfilter.xml)
        iconpack/src/main/res/xml/drawable.xml
"""
import os
import pathlib
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
INPUT = ROOT / "iconpack-input"
MAIN = ROOT / "iconpack" / "src" / "main"
DRAWABLES = MAIN / "res" / "drawable-nodpi"
NAME_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def summary(text):
    print(text)
    path = os.environ.get("GITHUB_STEP_SUMMARY")
    if path:
        with open(path, "a", encoding="utf-8") as f:
            f.write(text + "\n")


def commit_time(p):
    try:
        out = subprocess.run(["git", "log", "-1", "--format=%ct", "--", str(p)],
                             cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip()
        return int(out or 0)
    except Exception:
        return 0


def main():
    zips = sorted(INPUT.glob("*.zip"), key=lambda p: (commit_time(p), p.stat().st_mtime))
    if not zips:
        summary("⚠️ Nincs ZIP az iconpack-input mappában — az ikoncsomag üresen épül.")
        return 0
    src = zips[-1]
    summary(f"📦 Felhasznált ZIP: `{src.name}`")

    for old in DRAWABLES.glob("ic_*.png"):
        old.unlink()
    DRAWABLES.mkdir(parents=True, exist_ok=True)

    names = set()
    appfilter = drawable = None
    with zipfile.ZipFile(src) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            base = pathlib.PurePosixPath(info.filename).name  # zip-slip ellen csak a fájlnév
            if base.lower().endswith(".png"):
                stem = base[:-4]
                if not NAME_RE.match(stem):
                    print(f"  kihagyva (rossz név): {base}")
                    continue
                (DRAWABLES / base).write_bytes(z.read(info))
                names.add(stem)
            elif base == "appfilter.xml":
                appfilter = z.read(info)
            elif base == "drawable.xml":
                drawable = z.read(info)

    if appfilter is None:
        summary("❌ A ZIP-ben nincs appfilter.xml.")
        return 1

    # Ellenőrzés: csak olyan bejegyzés maradjon, amihez van kép
    tree = ET.ElementTree(ET.fromstring(appfilter))
    root = tree.getroot()
    removed = 0
    for item in list(root.findall("item")):
        if item.get("drawable") not in names:
            root.remove(item)
            removed += 1
    data = b'<?xml version="1.0" encoding="utf-8"?>\n' + ET.tostring(root, encoding="utf-8")
    for target in (MAIN / "res" / "xml" / "appfilter.xml", MAIN / "assets" / "appfilter.xml"):
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)

    if drawable is None:
        lines = ['<?xml version="1.0" encoding="utf-8"?>', "<resources>", "    <version>1</version>"]
        lines += [f'    <item drawable="{n}" />' for n in sorted(names)]
        lines.append("</resources>")
        drawable = ("\n".join(lines) + "\n").encode()
    (MAIN / "res" / "xml" / "drawable.xml").write_bytes(drawable)

    summary(f"✅ {len(root.findall('item'))} ikon beillesztve"
            + (f" ({removed} bejegyzés kép nélkül, kihagyva)" if removed else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
