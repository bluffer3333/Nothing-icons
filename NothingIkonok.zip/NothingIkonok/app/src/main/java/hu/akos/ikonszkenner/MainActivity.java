package hu.akos.ikonszkenner;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {

    private static final int REQ_SAVE = 42;
    private static final int RED = 0xFFD71921;

    static final class Item {
        String label;
        ComponentName cn;
        Drawable icon;
        boolean hasMono;
        NothingStyle.Mode mode;
        Bitmap preview;
        String resName;
    }

    private final List<Item> items = new ArrayList<>();
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private SharedPreferences prefs;
    private TextView status;
    private Button scanBtn, themeBtn, saveBtn;
    private IconAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("modes", MODE_PRIVATE);
        NothingStyle.cfg = StyleSettings.load(this);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, 0);

        TextView title = new TextView(this);
        title.setText("IKON SZKENNER");
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        title.setLetterSpacing(0.12f);
        root.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Koppintás: stílus váltása  •  Hosszú nyomás: vissza Auto-ra");
        hint.setTextColor(0xFF9A9A9A);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        hint.setPadding(0, dp(4), 0, dp(12));
        root.addView(hint);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        scanBtn = makeButton("SZKENNEL", false);
        themeBtn = makeButton("STÍLUS", false);
        saveBtn = makeButton("MENTÉS", true);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        lp1.setMarginEnd(dp(8));
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        lp2.setMarginEnd(dp(8));
        row.addView(scanBtn, lp1);
        row.addView(themeBtn, lp2);
        row.addView(saveBtn, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(row);

        status = new TextView(this);
        status.setTextColor(0xFFCCCCCC);
        status.setTypeface(Typeface.MONOSPACE);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        status.setPadding(0, dp(12), 0, dp(8));
        root.addView(status);

        GridView grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setVerticalSpacing(dp(14));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(new GradientDrawable());
        grid.setClipToPadding(false);
        grid.setPadding(0, 0, 0, dp(24));
        adapter = new IconAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, view, position, id) -> cycleMode(items.get(position)));
        grid.setOnItemLongClickListener((parent, view, position, id) -> {
            setMode(items.get(position), NothingStyle.Mode.AUTO);
            return true;
        });
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        scanBtn.setOnClickListener(v -> scan());
        saveBtn.setOnClickListener(v -> askSaveLocation());
        themeBtn.setOnClickListener(v -> StyleSettings.show(this,
                items.isEmpty() ? null : items.get(0).icon, this::applyStyle));
        scan();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        exec.shutdownNow();
    }

    // ---------------------------------------------------------------- szkennelés

    private void scan() {
        setBusy(true);
        status.setText("Appok keresése…");
        exec.execute(() -> {
            PackageManager pm = getPackageManager();
            Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(launcher, 0);
            List<Item> result = new ArrayList<>();
            int done = 0;
            for (ResolveInfo ri : list) {
                done++;
                try {
                    ActivityInfo ai = ri.activityInfo;
                    Item it = new Item();
                    it.cn = new ComponentName(ai.packageName, ai.name);
                    it.label = String.valueOf(ri.loadLabel(pm));
                    it.icon = ri.loadIcon(pm);
                    it.hasMono = NothingStyle.hasMonochrome(it.icon);
                    it.mode = loadMode(it);
                    it.preview = NothingStyle.render(it.icon, it.mode);
                    it.resName = resName(it.cn);
                    result.add(it);
                } catch (Throwable ignored) {
                    // egy hibás ikon ne állítsa meg a többit
                }
                final int d = done, total = list.size();
                if (d % 5 == 0 || d == total) {
                    ui.post(() -> status.setText("Átalakítás: " + d + " / " + total));
                }
            }
            Collator col = Collator.getInstance(new Locale("hu", "HU"));
            result.sort((a, b) -> col.compare(a.label, b.label));
            ui.post(() -> {
                items.clear();
                items.addAll(result);
                adapter.notifyDataSetChanged();
                int mono = 0;
                for (Item it : items) if (it.hasMono) mono++;
                status.setText(items.size() + " app  •  " + mono + " saját monokróm ikonnal");
                setBusy(false);
            });
        });
    }

    /** Új stílus alkalmazása: mentés és az összes ikon újrarajzolása. */
    private void applyStyle(NothingStyle.Config c) {
        NothingStyle.cfg = c;
        StyleSettings.save(this, c);
        setBusy(true);
        final List<Item> snapshot = new ArrayList<>(items);
        exec.execute(() -> {
            int done = 0;
            for (Item it : snapshot) {
                Bitmap b = NothingStyle.render(it.icon, it.mode, c);
                done++;
                final int d = done;
                ui.post(() -> {
                    it.preview = b;
                    if (d % 8 == 0) adapter.notifyDataSetChanged();
                    status.setText("Újrarajzolás: " + d + " / " + snapshot.size());
                });
            }
            ui.post(() -> {
                adapter.notifyDataSetChanged();
                status.setText(snapshot.size() + " app  •  " + StyleSettings.describe(c));
                setBusy(false);
            });
        });
    }

    private NothingStyle.Mode loadMode(Item it) {
        String s = prefs.getString(it.cn.flattenToString(), null);
        if (s != null) {
            try {
                NothingStyle.Mode m = NothingStyle.Mode.valueOf(s);
                if (m != NothingStyle.Mode.EXTRACT || it.hasMono) return m;
            } catch (IllegalArgumentException ignored) {
            }
        }
        return NothingStyle.Mode.AUTO;
    }

    private void cycleMode(Item it) {
        NothingStyle.Mode[] modes = NothingStyle.modesFor(it.hasMono);
        int idx = 0;
        for (int i = 0; i < modes.length; i++) if (modes[i] == it.mode) idx = i;
        setMode(it, modes[(idx + 1) % modes.length]);
    }

    private void setMode(Item it, NothingStyle.Mode mode) {
        it.mode = mode;
        if (mode == NothingStyle.Mode.AUTO) {
            prefs.edit().remove(it.cn.flattenToString()).apply();
        } else {
            prefs.edit().putString(it.cn.flattenToString(), mode.name()).apply();
        }
        Toast.makeText(this, it.label + ": " + mode.label, Toast.LENGTH_SHORT).show();
        exec.execute(() -> {
            Bitmap b = NothingStyle.render(it.icon, mode);
            ui.post(() -> {
                it.preview = b;
                adapter.notifyDataSetChanged();
            });
        });
    }

    static String resName(ComponentName cn) {
        String s = cn.getPackageName().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_]", "_");
        if (s.length() > 60) s = s.substring(0, 60);
        return "ic_" + s + "_" + Integer.toHexString(cn.flattenToString().hashCode());
    }

    // ---------------------------------------------------------------- mentés

    private void askSaveLocation() {
        if (items.isEmpty()) {
            Toast.makeText(this, "Előbb szkennelj!", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        i.putExtra(Intent.EXTRA_TITLE, "ikonok.zip");
        startActivityForResult(i, REQ_SAVE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SAVE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            writeZip(data.getData());
        }
    }

    private void writeZip(Uri uri) {
        setBusy(true);
        status.setText("ZIP írása…");
        final List<Item> snapshot = new ArrayList<>(items);
        exec.execute(() -> {
            String error = null;
            try (OutputStream os = getContentResolver().openOutputStream(uri);
                 ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(os))) {

                StringBuilder af = new StringBuilder();
                af.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n");
                StringBuilder dx = new StringBuilder();
                dx.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n")
                        .append("    <version>1</version>\n")
                        .append("    <category title=\"Összes\" />\n");

                for (Item it : snapshot) {
                    zos.putNextEntry(new ZipEntry("icons/" + it.resName + ".png"));
                    it.preview.compress(Bitmap.CompressFormat.PNG, 100, zos);
                    zos.closeEntry();

                    af.append("    <!-- ").append(it.label.replace("--", "- -")).append(" -->\n");
                    af.append("    <item component=\"ComponentInfo{")
                            .append(xml(it.cn.getPackageName() + "/" + it.cn.getClassName()))
                            .append("}\" drawable=\"").append(it.resName).append("\" />\n");
                    dx.append("    <item drawable=\"").append(it.resName).append("\" />\n");
                }
                af.append("</resources>\n");
                dx.append("</resources>\n");

                putText(zos, "appfilter.xml", af.toString());
                putText(zos, "drawable.xml", dx.toString());
                String info = "Ikon Szkenner export\n"
                        + "Dátum: " + new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ROOT).format(new Date()) + "\n"
                        + "Eszköz: " + Build.MANUFACTURER + " " + Build.MODEL + "\n"
                        + "Ikonok: " + snapshot.size() + "\n"
                        + "Stílus: " + StyleSettings.describe(NothingStyle.cfg) + "\n";
                putText(zos, "info.txt", info);
            } catch (Exception e) {
                error = e.getMessage();
            }
            final String err = error;
            ui.post(() -> {
                setBusy(false);
                if (err == null) {
                    status.setText("Kész: " + snapshot.size() + " ikon elmentve. Töltsd fel a GitHub repó iconpack-input mappájába.");
                } else {
                    status.setText("Hiba a mentésnél: " + err);
                }
            });
        });
    }

    private static void putText(ZipOutputStream zos, String name, String text) throws java.io.IOException {
        zos.putNextEntry(new ZipEntry(name));
        zos.write(text.getBytes(StandardCharsets.UTF_8));
        zos.closeEntry();
    }

    private static String xml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    // ---------------------------------------------------------------- UI segédek

    private void setBusy(boolean busy) {
        for (Button b : new Button[]{scanBtn, themeBtn, saveBtn}) {
            b.setEnabled(!busy);
            b.setAlpha(busy ? 0.4f : 1f);
        }
    }

    private Button makeButton(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        b.setTextColor(primary ? Color.WHITE : Color.BLACK);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(24));
        bg.setColor(primary ? RED : Color.WHITE);
        b.setBackground(bg);
        b.setStateListAnimator(null);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private final class IconAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout cell;
            ImageView iv;
            TextView name, mode;
            if (convertView == null) {
                cell = new LinearLayout(MainActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                iv = new ImageView(MainActivity.this);
                cell.addView(iv, new LinearLayout.LayoutParams(dp(60), dp(60)));
                name = new TextView(MainActivity.this);
                name.setTextColor(0xFFDDDDDD);
                name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
                name.setSingleLine(true);
                name.setEllipsize(TextUtils.TruncateAt.END);
                name.setGravity(Gravity.CENTER);
                name.setPadding(dp(2), dp(4), dp(2), 0);
                cell.addView(name, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                mode = new TextView(MainActivity.this);
                mode.setTextColor(RED);
                mode.setTypeface(Typeface.MONOSPACE);
                mode.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
                mode.setGravity(Gravity.CENTER);
                cell.addView(mode, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                cell.setTag(new View[]{iv, name, mode});
            } else {
                cell = (LinearLayout) convertView;
                View[] v = (View[]) cell.getTag();
                iv = (ImageView) v[0];
                name = (TextView) v[1];
                mode = (TextView) v[2];
            }
            Item it = items.get(position);
            iv.setImageBitmap(it.preview);
            name.setText(it.label);
            mode.setText(it.mode == NothingStyle.Mode.AUTO ? " " : it.mode.label.toUpperCase(Locale.ROOT));
            return cell;
        }
    }
}
