package hu.akos.ikonszkenner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.function.Consumer;

/** A stílus- és színbeállító menü, plusz a beállítások mentése. */
public final class StyleSettings {

    private static final int RED = 0xFFD71921;

    /** Kész színsémák: név, háttér, vonal, kiemelés. */
    private static final Object[][] PRESETS = {
            {"Sötét • piros", 0xFF1B1B1B, 0xFFFFFFFF, RED},
            {"Világos • piros", 0xFFEEEEEE, 0xFF000000, RED},
            {"Sötét • fehér", 0xFF1B1B1B, 0xFFFFFFFF, 0xFFFFFFFF},
            {"Világos • fekete", 0xFFEEEEEE, 0xFF000000, 0xFF000000},
            {"Piros kör", RED, 0xFFFFFFFF, 0xFF000000},
            {"Fekete • szürke", 0xFF000000, 0xFFFFFFFF, 0xFF8A8A8A},
    };

    /** Egyéni színválasztó palettája. */
    private static final int[] SWATCHES = {
            0xFF000000, 0xFF1B1B1B, 0xFF3A3A3A, 0xFF8A8A8A, 0xFFEEEEEE, 0xFFFFFFFF,
            RED, 0xFFFF6B00, 0xFFFFC400, 0xFF2ECC71, 0xFF1E88E5, 0xFF8E44AD,
    };

    private static final float[] STROKES = {0.03f, 0.04f, 0.052f};
    private static final String[] STROKE_NAMES = {"Vékony", "Közepes", "Vastag"};

    private StyleSettings() {
    }

    // ------------------------------------------------------------ mentés

    public static NothingStyle.Config load(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE);
        NothingStyle.Config c = new NothingStyle.Config();
        c.line = p.getBoolean("line", c.line);
        c.circle = p.getBoolean("circle", c.circle);
        c.bg = p.getInt("bg", c.bg);
        c.fg = p.getInt("fg", c.fg);
        c.accent = p.getInt("accent", c.accent);
        c.stroke = p.getFloat("stroke", c.stroke);
        return c;
    }

    public static void save(Context ctx, NothingStyle.Config c) {
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).edit()
                .putBoolean("line", c.line)
                .putBoolean("circle", c.circle)
                .putInt("bg", c.bg)
                .putInt("fg", c.fg)
                .putInt("accent", c.accent)
                .putFloat("stroke", c.stroke)
                .apply();
    }

    public static String describe(NothingStyle.Config c) {
        String name = "egyéni színek";
        for (Object[] p : PRESETS) {
            if ((int) p[1] == c.bg && (int) p[2] == c.fg && (int) p[3] == c.accent) {
                name = (String) p[0];
                break;
            }
        }
        return (c.line ? "Vonalas" : "Kitöltött") + ", " + name + (c.circle ? "" : ", háttér nélkül");
    }

    // ------------------------------------------------------------ menü

    /**
     * Megnyitja a menüt. A sample ikonon élőben mutatja az eredményt;
     * "Alkalmaz"-ra az onApply kapja meg az új beállítást.
     */
    public static void show(Activity act, Drawable sample, Consumer<NothingStyle.Config> onApply) {
        new Builder(act, sample, onApply).open();
    }

    private static final class Builder {
        final Activity act;
        final Drawable sample;
        final Consumer<NothingStyle.Config> onApply;
        final NothingStyle.Config c;
        final Handler ui = new Handler(Looper.getMainLooper());
        final LinearLayout body;
        ImageView prevDark, prevLight;
        int renderToken = 0;

        Builder(Activity act, Drawable sample, Consumer<NothingStyle.Config> onApply) {
            this.act = act;
            this.sample = sample;
            this.onApply = onApply;
            this.c = NothingStyle.cfg.copy();
            body = new LinearLayout(act);
            body.setOrientation(LinearLayout.VERTICAL);
            body.setPadding(dp(20), dp(8), dp(20), dp(8));
        }

        void open() {
            rebuild();
            ScrollView sv = new ScrollView(act);
            sv.setBackgroundColor(0xFF111111);
            sv.addView(body);
            AlertDialog d = new AlertDialog.Builder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle("Ikonstílus")
                    .setView(sv)
                    .setNegativeButton("Mégse", null)
                    .setPositiveButton("Alkalmaz", (dlg, w) -> onApply.accept(c.copy()))
                    .create();
            d.show();
        }

        /** Az egész menü újraépítése (kijelölések frissítése). */
        void rebuild() {
            body.removeAllViews();

            // Előnézet: sötét és világos lapon is
            LinearLayout prev = new LinearLayout(act);
            prev.setGravity(Gravity.CENTER);
            prev.setPadding(0, dp(8), 0, dp(8));
            prevDark = previewTile(0xFF000000);
            prevLight = previewTile(0xFFBDBDBD);
            prev.addView((View) prevDark.getParent());
            prev.addView((View) prevLight.getParent());
            body.addView(prev);
            renderPreview();

            header("STÍLUS");
            LinearLayout styleRow = row();
            styleRow.addView(chip("Vonalas", c.line, v -> { c.line = true; rebuild(); }));
            styleRow.addView(chip("Kitöltött", !c.line, v -> { c.line = false; rebuild(); }));
            body.addView(styleRow);

            header("HÁTTÉR");
            LinearLayout bgRow = row();
            bgRow.addView(chip("Kör", c.circle, v -> { c.circle = true; rebuild(); }));
            bgRow.addView(chip("Nincs", !c.circle, v -> { c.circle = false; rebuild(); }));
            body.addView(bgRow);

            if (c.line) {
                header("VONALVASTAGSÁG");
                LinearLayout sRow = row();
                for (int i = 0; i < STROKES.length; i++) {
                    final float s = STROKES[i];
                    sRow.addView(chip(STROKE_NAMES[i], Math.abs(c.stroke - s) < 0.001f,
                            v -> { c.stroke = s; rebuild(); }));
                }
                body.addView(sRow);
            }

            header("SZÍNSÉMA");
            LinearLayout grid = new LinearLayout(act);
            grid.setOrientation(LinearLayout.VERTICAL);
            LinearLayout cur = null;
            for (int i = 0; i < PRESETS.length; i++) {
                if (i % 2 == 0) {
                    cur = row();
                    grid.addView(cur);
                }
                final Object[] p = PRESETS[i];
                boolean sel = (int) p[1] == c.bg && (int) p[2] == c.fg && (int) p[3] == c.accent;
                cur.addView(presetChip(p, sel));
            }
            body.addView(grid);

            header("EGYÉNI SZÍNEK");
            swatchRow("Háttér", c.bg, col -> c.bg = col);
            swatchRow(c.line ? "Vonal" : "Jel", c.fg, col -> c.fg = col);
            if (c.line) {
                swatchRow("Kiemelés", c.accent, col -> c.accent = col);
            }
        }

        void renderPreview() {
            if (sample == null) return;
            final int token = ++renderToken;
            final NothingStyle.Config snap = c.copy();
            new Thread(() -> {
                Bitmap b = NothingStyle.render(sample, NothingStyle.Mode.AUTO, snap);
                ui.post(() -> {
                    if (token != renderToken) return;
                    prevDark.setImageBitmap(b);
                    prevLight.setImageBitmap(b);
                });
            }).start();
        }

        ImageView previewTile(int pageColor) {
            LinearLayout box = new LinearLayout(act);
            box.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setColor(pageColor);
            g.setCornerRadius(dp(16));
            box.setBackground(g);
            box.setPadding(dp(14), dp(14), dp(14), dp(14));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(100), dp(100));
            lp.setMargins(dp(6), 0, dp(6), 0);
            box.setLayoutParams(lp);
            ImageView iv = new ImageView(act);
            box.addView(iv, new LinearLayout.LayoutParams(dp(72), dp(72)));
            if (sample == null) {
                TextView t = new TextView(act);
                t.setText("Előbb szkennelj");
                t.setTextColor(0xFF888888);
                t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
                box.addView(t);
            }
            return iv;
        }

        void header(String text) {
            TextView t = new TextView(act);
            t.setText(text);
            t.setTextColor(0xFF9A9A9A);
            t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            t.setLetterSpacing(0.1f);
            t.setPadding(0, dp(16), 0, dp(6));
            body.addView(t);
        }

        LinearLayout row() {
            LinearLayout r = new LinearLayout(act);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setPadding(0, 0, 0, dp(6));
            return r;
        }

        TextView chip(String text, boolean selected, View.OnClickListener l) {
            TextView t = new TextView(act);
            t.setText(text);
            t.setGravity(Gravity.CENTER);
            t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            t.setTextColor(selected ? Color.BLACK : Color.WHITE);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(20));
            g.setColor(selected ? Color.WHITE : 0xFF262626);
            t.setBackground(g);
            t.setPadding(dp(16), dp(10), dp(16), dp(10));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMarginEnd(dp(6));
            t.setLayoutParams(lp);
            t.setOnClickListener(l);
            return t;
        }

        View presetChip(Object[] p, boolean selected) {
            LinearLayout box = new LinearLayout(act);
            box.setOrientation(LinearLayout.HORIZONTAL);
            box.setGravity(Gravity.CENTER_VERTICAL);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(14));
            g.setColor(0xFF262626);
            if (selected) g.setStroke(dp(2), RED);
            box.setBackground(g);
            box.setPadding(dp(10), dp(10), dp(10), dp(10));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMarginEnd(dp(6));
            box.setLayoutParams(lp);
            for (int k = 1; k <= 3; k++) {
                View dot = new View(act);
                GradientDrawable dg = new GradientDrawable();
                dg.setShape(GradientDrawable.OVAL);
                dg.setColor((int) p[k]);
                dg.setStroke(1, 0xFF555555);
                dot.setBackground(dg);
                LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(14), dp(14));
                dl.setMarginEnd(dp(3));
                box.addView(dot, dl);
            }
            TextView t = new TextView(act);
            t.setText((String) p[0]);
            t.setTextColor(Color.WHITE);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            t.setPadding(dp(6), 0, 0, 0);
            t.setSingleLine(true);
            box.addView(t);
            box.setOnClickListener(v -> {
                c.bg = (int) p[1];
                c.fg = (int) p[2];
                c.accent = (int) p[3];
                rebuild();
            });
            return box;
        }

        void swatchRow(String label, int current, java.util.function.IntConsumer set) {
            TextView t = new TextView(act);
            t.setText(label);
            t.setTextColor(Color.WHITE);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            t.setPadding(0, dp(4), 0, dp(4));
            body.addView(t);
            HorizontalScrollView hs = new HorizontalScrollView(act);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout r = row();
            for (int col : SWATCHES) {
                View dot = new View(act);
                GradientDrawable dg = new GradientDrawable();
                dg.setShape(GradientDrawable.OVAL);
                dg.setColor(col);
                dg.setStroke(col == current ? dp(3) : 1, col == current ? RED : 0xFF555555);
                dot.setBackground(dg);
                LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(34), dp(34));
                dl.setMarginEnd(dp(8));
                dot.setOnClickListener(v -> {
                    set.accept(col);
                    rebuild();
                });
                r.addView(dot, dl);
            }
            hs.addView(r);
            body.addView(hs);
        }

        int dp(int v) {
            return Math.round(v * act.getResources().getDisplayMetrics().density);
        }
    }
}
