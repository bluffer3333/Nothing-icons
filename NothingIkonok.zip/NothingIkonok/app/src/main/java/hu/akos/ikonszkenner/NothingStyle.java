package hu.akos.ikonszkenner;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;

/**
 * Bármilyen app-ikonból Nothing-stílusú ikont készít.
 * - Kitöltött: egyszínű jel körön
 * - Vonalas: körvonalas jel, a belső részletek (vagy a kontúr egy íve) kiemelő színnel
 */
public final class NothingStyle {

    /** A kimeneti PNG mérete (xxxhdpi launcher-ikon). */
    public static final int OUT = 192;
    /** Belső munkaméret az elemzéshez. */
    private static final int W = 256;

    /** A megjelenés beállításai (a menüből állítható). */
    public static final class Config {
        /** true = vonalas, false = kitöltött */
        public boolean line = true;
        /** true = kör háttér, false = átlátszó */
        public boolean circle = true;
        public int bg = 0xFF1B1B1B;
        public int fg = 0xFFFFFFFF;
        public int accent = 0xFFD71921;
        /** vonalvastagság a teljes ikonmérethez képest */
        public float stroke = 0.04f;

        public Config copy() {
            Config c = new Config();
            c.line = line;
            c.circle = circle;
            c.bg = bg;
            c.fg = fg;
            c.accent = accent;
            c.stroke = stroke;
            return c;
        }
    }

    public static volatile Config cfg = new Config();

    /** A jel legnagyobb kiterjedése a kör átmérőjéhez képest. */
    private static final float GLYPH_BOX = 0.50f;
    private static final float LINE_BOX = 0.48f;
    /** Vonalas stílus túlmintavételezése (élsimításhoz). */
    private static final int SS = 3;

    public enum Mode {
        /** Az app saját monokróm rétege, ha van; különben automatikus kivonás. */
        AUTO("Auto"),
        /** Kivonás a színes ikonból akkor is, ha van monokróm réteg. */
        EXTRACT("Kivont"),
        /** Kivonás fordított (inverz) jellel. */
        INVERT("Inverz"),
        /** Az eredeti ikon szürkeárnyalatban, sötét körön. */
        GRAY("Szürke");

        public final String label;

        Mode(String label) {
            this.label = label;
        }
    }

    private NothingStyle() {
    }

    public static Mode[] modesFor(boolean hasMono) {
        if (hasMono) {
            return new Mode[]{Mode.AUTO, Mode.EXTRACT, Mode.INVERT, Mode.GRAY};
        }
        return new Mode[]{Mode.AUTO, Mode.INVERT, Mode.GRAY};
    }

    public static boolean hasMonochrome(Drawable d) {
        return Build.VERSION.SDK_INT >= 33
                && d instanceof AdaptiveIconDrawable
                && ((AdaptiveIconDrawable) d).getMonochrome() != null;
    }

    public static Bitmap render(Drawable icon, Mode mode) {
        return render(icon, mode, cfg);
    }

    public static Bitmap render(Drawable icon, Mode mode, Config c) {
        try {
            if (mode == Mode.GRAY) {
                return gray(icon, c);
            }
            float[] mask;
            if (mode == Mode.AUTO && hasMonochrome(icon)) {
                mask = alphaMask(drawToBitmap(((AdaptiveIconDrawable) icon).getMonochrome()));
            } else {
                mask = extract(icon, mode == Mode.INVERT);
            }
            Bitmap out = c.line ? lineStyle(mask, c) : compose(mask, c);
            return out != null ? out : gray(icon, c);
        } catch (Throwable t) {
            return gray(icon, c);
        }
    }

    // ------------------------------------------------------------------

    private static Bitmap drawToBitmap(Drawable d) {
        Bitmap b = Bitmap.createBitmap(W, W, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Rect old = d.copyBounds();
        d.setBounds(0, 0, W, W);
        d.draw(c);
        d.setBounds(old);
        return b;
    }

    private static float[] alphaMask(Bitmap b) {
        int[] px = new int[W * W];
        b.getPixels(px, 0, W, 0, 0, W, W);
        float[] m = new float[W * W];
        for (int i = 0; i < px.length; i++) {
            m[i] = (px[i] >>> 24) / 255f;
        }
        return m;
    }

    /**
     * Kivonja a "jelet" a színes ikonból.
     * - Ha az ikonnak van kitöltött háttere (kör/négyzet), a háttérszíntől
     *   eltérő pixelek lesznek a jel.
     * - Ha átlátszó hátterű (szabálytalan alakú) ikon, maga az alak lesz a
     *   jel, a benne lévő fehér részletek pedig kivágások.
     */
    private static float[] extract(Drawable icon, boolean flip) {
        Bitmap b = drawToBitmap(icon);
        int[] px = new int[W * W];
        b.getPixels(px, 0, W, 0, 0, W, W);

        // Az átlátszatlan rész befoglaló doboza
        int minX = W, minY = W, maxX = -1, maxY = -1;
        for (int y = 0; y < W; y++) {
            for (int x = 0; x < W; x++) {
                if ((px[y * W + x] >>> 24) > 128) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        float[] m = new float[W * W];
        if (maxX < 0) {
            return m;
        }
        float cx = (minX + maxX) / 2f;
        float cy = (minY + maxY) / 2f;
        float rad = Math.max(maxX - minX, maxY - minY) / 2f;
        if (rad < 4) {
            return m;
        }

        // Háttérszín becslése a szél közelében lévő gyűrűből (hisztogram-módusz)
        int[] counts = new int[4096];
        long[] sr = new long[4096], sg = new long[4096], sb = new long[4096];
        int ringTotal = 0, ringOpaque = 0;
        float[] rr = new float[W * W];
        for (int y = 0; y < W; y++) {
            for (int x = 0; x < W; x++) {
                int i = y * W + x;
                float dx = x - cx, dy = y - cy;
                float r = (float) Math.sqrt(dx * dx + dy * dy) / rad;
                rr[i] = r;
                if (r >= 0.78f && r <= 0.92f) {
                    ringTotal++;
                    int c = px[i];
                    if ((c >>> 24) > 200) {
                        ringOpaque++;
                        int cr = (c >> 16) & 0xFF, cg = (c >> 8) & 0xFF, cb = c & 0xFF;
                        int bin = ((cr >> 4) << 8) | ((cg >> 4) << 4) | (cb >> 4);
                        counts[bin]++;
                        sr[bin] += cr;
                        sg[bin] += cg;
                        sb[bin] += cb;
                    }
                }
            }
        }

        boolean transparentBg = ringTotal == 0 || ringOpaque < ringTotal * 0.5f;
        boolean[] region = new boolean[W * W];
        int regionCount = 0;

        if (transparentBg) {
            // Az alak maga a jel; a benne lévő (szürkés)fehér részek kivágások
            int opaque = 0, whiteCount = 0;
            for (int i = 0; i < px.length; i++) {
                int a = px[i] >>> 24;
                if (a > 128) {
                    opaque++;
                    if (isWhitish(px[i])) whiteCount++;
                }
            }
            boolean cutWhite = opaque > 0 && whiteCount < opaque * 0.5f;
            for (int i = 0; i < px.length; i++) {
                int c = px[i];
                float a = (c >>> 24) / 255f;
                region[i] = a > 0.5f;
                if (region[i]) regionCount++;
                float v = a;
                if (cutWhite) {
                    v *= 1f - whiteness(c);
                }
                m[i] = v;
            }
        } else {
            // Háttérpaletta: a gyűrű leggyakoribb színei (színátmenetes hátterekhez is)
            Integer[] order = new Integer[4096];
            for (int k = 0; k < 4096; k++) order[k] = k;
            java.util.Arrays.sort(order, (x, y) -> Integer.compare(counts[y], counts[x]));
            float[] palR = new float[24], palG = new float[24], palB = new float[24];
            int pal = 0, acc0 = 0;
            for (int k : order) {
                int cnt = counts[k];
                if (cnt == 0 || pal >= 24) break;
                if (pal > 0 && (cnt < ringOpaque * 0.02f || acc0 >= ringOpaque * 0.9f)) break;
                palR[pal] = sr[k] / (float) cnt;
                palG[pal] = sg[k] / (float) cnt;
                palB[pal] = sb[k] / (float) cnt;
                pal++;
                acc0 += cnt;
            }

            float[] d = new float[W * W];
            int[] hist = new int[256];
            for (int i = 0; i < px.length; i++) {
                int c = px[i];
                int a = c >>> 24;
                if (a < 16 || rr[i] > 0.93f) {
                    continue;
                }
                int cr = (c >> 16) & 0xFF, cg = (c >> 8) & 0xFF, cb = c & 0xFF;
                float minSq = Float.MAX_VALUE;
                for (int k = 0; k < pal; k++) {
                    float dr = cr - palR[k], dg = cg - palG[k], db = cb - palB[k];
                    float sq = dr * dr + dg * dg + db * db;
                    if (sq < minSq) minSq = sq;
                }
                float dist = (float) Math.sqrt(minSq) / 441.673f;
                d[i] = dist;
                if (a > 128) {
                    region[i] = true;
                    regionCount++;
                    hist[Math.min(255, (int) (dist * 255f))]++;
                }
            }
            // 98. percentilis -> adaptív küszöb (halvány kontrasztú ikonokhoz is)
            float p98 = 0f;
            int target = (int) (regionCount * 0.98f), acc = 0;
            for (int k = 0; k < 256; k++) {
                acc += hist[k];
                if (acc >= target) {
                    p98 = k / 255f;
                    break;
                }
            }
            float hi = clamp(p98 * 0.5f, 0.06f, 0.35f);
            float lo = hi * 0.35f;
            for (int i = 0; i < px.length; i++) {
                if (d[i] <= 0f) continue;
                float a = (px[i] >>> 24) / 255f;
                m[i] = smoothstep(lo, hi, d[i]) * a;
            }
        }

        // Ha a "jel" szinte az egészet kitölti, valójában fordítva van
        float sum = 0f;
        for (int i = 0; i < m.length; i++) {
            if (region[i]) sum += m[i];
        }
        boolean autoInvert = !transparentBg && regionCount > 0 && sum / regionCount > 0.5f;
        boolean invert = flip != autoInvert;
        if (invert) {
            for (int i = 0; i < m.length; i++) {
                m[i] = region[i] ? 1f - m[i] : 0f;
            }
        }
        return m;
    }

    /** A maszk befoglaló doboza: {minX, minY, maxX, maxY}, vagy null ha üres. */
    private static int[] bbox(float[] m) {
        int minX = W, minY = W, maxX = -1, maxY = -1;
        for (int y = 0; y < W; y++) {
            for (int x = 0; x < W; x++) {
                if (m[y * W + x] > 0.08f) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        if (maxX < 0 || (maxX - minX) < 2 || (maxY - minY) < 2) {
            return null;
        }
        return new int[]{minX, minY, maxX, maxY};
    }

    /** A maszk kivágott részéből fehér-alfa bitmapet készít. */
    private static Bitmap glyphBitmap(float[] m, int[] bb, int rgb) {
        int minX = bb[0], minY = bb[1], maxX = bb[2], maxY = bb[3];
        int bw = maxX - minX + 1, bh = maxY - minY + 1;
        int[] gp = new int[bw * bh];
        for (int y = 0; y < bh; y++) {
            for (int x = 0; x < bw; x++) {
                int a = Math.round(clamp(m[(y + minY) * W + (x + minX)], 0f, 1f) * 255f);
                gp[y * bw + x] = (a << 24) | (rgb & 0xFFFFFF);
            }
        }
        return Bitmap.createBitmap(gp, bw, bh, Bitmap.Config.ARGB_8888);
    }

    /** Kitöltött stílus: a jel egy színnel, körön. */
    private static Bitmap compose(float[] m, Config cf) {
        int[] bb = bbox(m);
        if (bb == null) return null;
        Bitmap glyph = glyphBitmap(m, bb, cf.fg);
        int bw = glyph.getWidth(), bh = glyph.getHeight();

        Bitmap out = Bitmap.createBitmap(OUT, OUT, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        if (cf.circle) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(cf.bg);
            c.drawCircle(OUT / 2f, OUT / 2f, OUT / 2f, p);
        }
        float scale = (OUT * GLYPH_BOX) / Math.max(bw, bh);
        float dw = bw * scale, dh = bh * scale;
        RectF dst = new RectF((OUT - dw) / 2f, (OUT - dh) / 2f, (OUT + dw) / 2f, (OUT + dh) / 2f);
        Paint gpaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        c.drawBitmap(glyph, null, dst, gpaint);
        glyph.recycle();
        return out;
    }

    /**
     * Vonalas stílus: a jel körvonala vonalszínnel, a belső részletek
     * kiemelő színnel. Ha nincs belső részlet, a kontúr jobb alsó íve lesz
     * kiemelt. SS-szeres felbontásban számol, majd átlagolva kicsinyít.
     */
    private static Bitmap lineStyle(float[] m, Config cf) {
        int[] bb = bbox(m);
        if (bb == null) return null;
        final int S = OUT * SS;
        final int n = S * S;

        Bitmap glyph = glyphBitmap(m, bb, 0xFFFFFF);
        int bw = glyph.getWidth(), bh = glyph.getHeight();
        Bitmap big = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(big);
        float scale = (S * LINE_BOX) / Math.max(bw, bh);
        float dw = bw * scale, dh = bh * scale;
        RectF dst = new RectF((S - dw) / 2f, (S - dh) / 2f, (S + dw) / 2f, (S + dh) / 2f);
        c.drawBitmap(glyph, null, dst, new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
        glyph.recycle();
        int[] px = new int[n];
        big.getPixels(px, 0, S, 0, 0, S, S);
        big.recycle();

        boolean[] shape = new boolean[n];
        for (int i = 0; i < n; i++) shape[i] = (px[i] >>> 24) > 127;
        px = null;

        double[] dB = distInside(shape, S);
        boolean[] outer = fillHoles(shape, S);
        double[] dO = distInside(outer, S);

        float w = cf.stroke * S;
        float[] so = new float[n];
        float[] in = new float[n];
        double soSum = 0, inSum = 0, sx = 0, sy = 0;
        int on = 0;
        for (int i = 0; i < n; i++) {
            float sb = shape[i] ? clamp(w + 0.5f - (float) dB[i], 0f, 1f) : 0f;
            float o = outer[i] ? clamp(w + 0.5f - (float) dO[i], 0f, 1f) : 0f;
            so[i] = o;
            in[i] = clamp(sb - o, 0f, 1f);
            soSum += o;
            inSum += in[i];
            if (outer[i]) {
                sx += i % S;
                sy += i / S;
                on++;
            }
        }
        if (on > 0 && inSum < soSum * 0.08) {
            double cx = sx / on, cy = sy / on;
            for (int i = 0; i < n; i++) {
                if (so[i] <= 0f) continue;
                double ang = Math.toDegrees(Math.atan2(i / S - cy, i % S - cx));
                if (ang > 15 && ang < 105) {
                    in[i] = so[i];
                    so[i] = 0f;
                }
            }
        }

        // Összerakás + SS×SS átlagolás (premultiplied)
        float bgR = ((cf.bg >> 16) & 0xFF), bgG = ((cf.bg >> 8) & 0xFF), bgB = (cf.bg & 0xFF);
        float fgR = ((cf.fg >> 16) & 0xFF), fgG = ((cf.fg >> 8) & 0xFF), fgB = (cf.fg & 0xFF);
        float acR = ((cf.accent >> 16) & 0xFF), acG = ((cf.accent >> 8) & 0xFF), acB = (cf.accent & 0xFF);
        float half = S / 2f;
        int[] out = new int[OUT * OUT];
        float inv = 1f / (SS * SS);
        for (int oy = 0; oy < OUT; oy++) {
            for (int ox = 0; ox < OUT; ox++) {
                float r = 0, g = 0, b = 0, a = 0;
                for (int sy2 = 0; sy2 < SS; sy2++) {
                    int y = oy * SS + sy2;
                    for (int sx2 = 0; sx2 < SS; sx2++) {
                        int x = ox * SS + sx2;
                        int i = y * S + x;
                        float pr = 0, pg = 0, pb = 0, pa = 0;
                        if (cf.circle) {
                            float dx = x + 0.5f - half, dy = y + 0.5f - half;
                            float ca = clamp(half - (float) Math.sqrt(dx * dx + dy * dy) + 0.5f, 0f, 1f);
                            pr = bgR * ca;
                            pg = bgG * ca;
                            pb = bgB * ca;
                            pa = ca;
                        }
                        float l = so[i];
                        if (l > 0f) {
                            pr = pr * (1 - l) + fgR * l;
                            pg = pg * (1 - l) + fgG * l;
                            pb = pb * (1 - l) + fgB * l;
                            pa = pa * (1 - l) + l;
                        }
                        float q = in[i];
                        if (q > 0f) {
                            pr = pr * (1 - q) + acR * q;
                            pg = pg * (1 - q) + acG * q;
                            pb = pb * (1 - q) + acB * q;
                            pa = pa * (1 - q) + q;
                        }
                        r += pr;
                        g += pg;
                        b += pb;
                        a += pa;
                    }
                }
                r *= inv;
                g *= inv;
                b *= inv;
                a *= inv;
                int ia = Math.round(a * 255f);
                if (ia <= 0) {
                    out[oy * OUT + ox] = 0;
                    continue;
                }
                int ir = Math.min(255, Math.round(r / a));
                int ig = Math.min(255, Math.round(g / a));
                int ib = Math.min(255, Math.round(b / a));
                out[oy * OUT + ox] = (ia << 24) | (ir << 16) | (ig << 8) | ib;
            }
        }
        return Bitmap.createBitmap(out, OUT, OUT, Bitmap.Config.ARGB_8888);
    }

    /** Lyukak kitöltése: ami a széltől nem érhető el a háttéren át, az az alakhoz tartozik. */
    private static boolean[] fillHoles(boolean[] shape, int S) {
        int n = S * S;
        boolean[] reach = new boolean[n];
        int[] queue = new int[n];
        int head = 0, tail = 0;
        for (int x = 0; x < S; x++) {
            int top = x, bottom = (S - 1) * S + x;
            if (!shape[top] && !reach[top]) { reach[top] = true; queue[tail++] = top; }
            if (!shape[bottom] && !reach[bottom]) { reach[bottom] = true; queue[tail++] = bottom; }
        }
        for (int y = 0; y < S; y++) {
            int left = y * S, right = y * S + S - 1;
            if (!shape[left] && !reach[left]) { reach[left] = true; queue[tail++] = left; }
            if (!shape[right] && !reach[right]) { reach[right] = true; queue[tail++] = right; }
        }
        while (head < tail) {
            int i = queue[head++];
            int x = i % S, y = i / S;
            if (x > 0) tail = visit(i - 1, shape, reach, queue, tail);
            if (x < S - 1) tail = visit(i + 1, shape, reach, queue, tail);
            if (y > 0) tail = visit(i - S, shape, reach, queue, tail);
            if (y < S - 1) tail = visit(i + S, shape, reach, queue, tail);
        }
        boolean[] filled = new boolean[n];
        for (int i = 0; i < n; i++) filled[i] = !reach[i];
        return filled;
    }

    private static int visit(int j, boolean[] shape, boolean[] reach, int[] queue, int tail) {
        if (!shape[j] && !reach[j]) {
            reach[j] = true;
            queue[tail++] = j;
        }
        return tail;
    }

    private static final double INF = 1e20;

    /** Pontos euklideszi távolság minden alakon belüli pixeltől a legközelebbi külső pixelig. */
    private static double[] distInside(boolean[] shape, int S) {
        int n = S * S;
        double[] g = new double[n];
        for (int i = 0; i < n; i++) g[i] = shape[i] ? INF : 0;
        double[] f = new double[S], d = new double[S];
        double[] z = new double[S + 1];
        int[] v = new int[S];
        for (int x = 0; x < S; x++) {
            for (int y = 0; y < S; y++) f[y] = g[y * S + x];
            edt1d(f, S, d, v, z);
            for (int y = 0; y < S; y++) g[y * S + x] = d[y];
        }
        for (int y = 0; y < S; y++) {
            System.arraycopy(g, y * S, f, 0, S);
            edt1d(f, S, d, v, z);
            for (int x = 0; x < S; x++) g[y * S + x] = Math.sqrt(d[x]);
        }
        return g;
    }

    /** Felzenszwalb–Huttenlocher 1D távolságtranszformáció. */
    private static void edt1d(double[] f, int n, double[] d, int[] v, double[] z) {
        int k = 0;
        v[0] = 0;
        z[0] = -INF;
        z[1] = INF;
        for (int q = 1; q < n; q++) {
            double s = ((f[q] + (double) q * q) - (f[v[k]] + (double) v[k] * v[k])) / (2.0 * q - 2.0 * v[k]);
            while (s <= z[k]) {
                k--;
                s = ((f[q] + (double) q * q) - (f[v[k]] + (double) v[k] * v[k])) / (2.0 * q - 2.0 * v[k]);
            }
            k++;
            v[k] = q;
            z[k] = s;
            z[k + 1] = INF;
        }
        k = 0;
        for (int q = 0; q < n; q++) {
            while (z[k + 1] < q) k++;
            double dq = q - v[k];
            d[q] = dq * dq + f[v[k]];
        }
    }

    private static Bitmap gray(Drawable icon, Config cf) {
        Bitmap src = drawToBitmap(icon);
        Bitmap out = Bitmap.createBitmap(OUT, OUT, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        if (cf.circle) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(cf.bg);
            c.drawCircle(OUT / 2f, OUT / 2f, OUT / 2f, p);
        }
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0f);
        Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        ip.setColorFilter(new ColorMatrixColorFilter(cm));
        float s = OUT * 0.66f;
        c.drawBitmap(src, null, new RectF((OUT - s) / 2f, (OUT - s) / 2f, (OUT + s) / 2f, (OUT + s) / 2f), ip);
        src.recycle();
        return out;
    }

    private static boolean isWhitish(int c) {
        return whiteness(c) > 0.5f;
    }

    /** 0..1: mennyire világos és színtelen a pixel. */
    private static float whiteness(int c) {
        int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
        int max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        float lum = max / 255f;
        float sat = max == 0 ? 0f : (max - min) / (float) max;
        return smoothstep(0.78f, 0.92f, lum) * (1f - smoothstep(0.12f, 0.25f, sat));
    }

    private static float smoothstep(float e0, float e1, float x) {
        float t = clamp((x - e0) / (e1 - e0), 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
