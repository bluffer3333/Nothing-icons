# Nothing Ikonok – saját, automatikus ikoncsomag

Két app egy repóban:

| App | Mit csinál |
|---|---|
| **Ikon Szkenner** (`IkonSzkenner-release.apk`) | Beolvassa a telefonon lévő összes appot, mindegyik ikonjából Nothing-stílusú ikont készít (vonalas, kétszínű vagy kitöltött), és az egészet elmenti egy `ikonok.zip` fájlba. |
| **Saját Nothing Ikonok** (`SajatNothingIkonok-release.apk`) | Maga az ikoncsomag, amit a Nothing Launcherben kiválasztasz. A GitHub Actions a ZIP-ből építi meg. |

## Első alkalom

1. Töltsd fel ennek a ZIP-nek a tartalmát a GitHub repóba (a `.github` mappával együtt).
2. Az **Actions** fülön lefut az „APK build”. A végén az **APK-k** artifactból telepítsd az `IkonSzkenner-release.apk`-t.
3. Nyisd meg az **Ikon Szkenner**t. Magától beolvassa az appokat.
   - **Koppintás** egy ikonra: stílusváltás → *Auto → (Kivont) → Inverz → Szürke*
     - *Auto*: ha az appnak van saját monokróm ikonja, azt használja, különben automatikusan kivonja a jelet a színes ikonból
     - *Kivont*: akkor is a színesből von ki, ha van saját monokróm ikon
     - *Inverz*: megfordítja, mi a jel és mi a háttér (ha az Auto rosszul találta el)
     - *Szürke*: az eredeti ikon szürkeárnyalatban, körön (bonyolult, fotószerű ikonokhoz)
   - **Hosszú nyomás**: vissza Auto-ra
   - **STÍLUS** gomb: megnyitja a stílusmenüt, élő előnézettel:
     - *Stílus*: **Vonalas** (alapértelmezett: körvonal + kiemelő szín) vagy **Kitöltött**
     - *Háttér*: kör vagy nincs (átlátszó)
     - *Vonalvastagság*: vékony / közepes / vastag
     - *Színséma*: Sötét • piros (alapértelmezett), Világos • piros, Sötét • fehér, Világos • fekete, Piros kör, Fekete • szürke
     - *Egyéni színek*: háttér, vonal és kiemelés külön-külön
   - Vonalas stílusnál a belső részletek (pl. kamera lencséje, boríték V-je) kapják a kiemelő színt. Ha az ikonnak nincs belső részlete, a körvonal jobb alsó íve lesz kiemelt.
4. Nyomd meg a **MENTÉS** gombot, és mentsd az `ikonok.zip`-et (pl. a Letöltések mappába).
5. A GitHubon: **iconpack-input** mappa → *Add file → Upload files* → töltsd fel az `ikonok.zip`-et → Commit.
6. Lefut az új build. Telepítsd a `SajatNothingIkonok-release.apk`-t.
7. **Beállítások → Testreszabás → Ikoncsomag → Saját Nothing Ikonok**.

## Ha új appot telepítesz

Szkenner → MENTÉS → töltsd fel az új ZIP-et ugyanabba a mappába (felülírhatod a régit) → telepítsd az új csomag APK-t.
A csomag minden buildnél nagyobb verziószámot kap, és mindkét app ugyanazzal a kulccsal van aláírva, így frissítésként települ.
Ha a launcher nem frissíti az ikonokat, válts át egy másik ikoncsomagra, majd vissza.

## Tudnivalók

- Ha a mappában több ZIP van, a build a legutóbb feltöltöttet használja.
- Az átalakítás automatikus, így bonyolult, sokszínű vagy fotószerű logóknál nem mindig tökéletes. Ilyenkor próbáld az *Inverz* vagy a *Szürke* módot.
- A szkenner által beállított módokat megjegyzi, újraszkennelés után is megmaradnak.
- Az aláíró kulcs a `keystore/ikon.jks` fájl (jelszó: `ikonpack`). Ne töröld, különben a frissítés előtt le kell törölni a régi appot.
