Ide töltsd fel az Ikon Szkenner által mentett `ikonok.zip` fájlt.
Ha több ZIP van itt, a legutóbb feltöltöttet használja a build.
